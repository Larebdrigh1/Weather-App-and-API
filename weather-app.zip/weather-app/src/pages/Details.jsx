import { useEffect, useState } from "react";
import { useLocation, useSearchParams } from "react-router-dom";
import { getWeatherForecastData } from "../apis";
import { Col, Container, Row } from "react-bootstrap";
import DailyForecast from "../components/DailyForecast";

const Details = () => {
  const location = useLocation();
  const { weatherData } = location.state || [];

  return (
    <Container className="py-4">
      <Row>
        <Col xs={12} className="mb-3">
          <h1 className="text-center">{weatherData.date}</h1>
        </Col>
      </Row>
      <Row style={{ rowGap: 30 }}>
        <Col xs={12}>
          <DailyForecast weatherData={weatherData} />
        </Col>
      </Row>
    </Container>
  );
};

export default Details;
