import { Button, Col, Container, Row } from "react-bootstrap";
import WeatherCard from "../components/WeatherCard";
import { useEffect, useState } from "react";
import Coordinates from "../components/Coordinates";
import { getCurrentWeatherData } from "../apis";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faLocationCrosshairs } from "@fortawesome/free-solid-svg-icons";
import { Link } from "react-router-dom";

const Home = () => {
  const [location, setLocation] = useState({ lat: 0, lng: 0 });
  const [selectedCityWeather, setSelectedCityWeather] = useState();
  const [searchText, setSearchText] = useState("");
  const [showDropdown, setShowDropdown] = useState(false);
  const [forceUpdateLocation, setForceUpdateLocation] = useState(false);

  const finlandCities = [
    { name: "Seinäjoki, South Ostrobothnia", lat: 62.791668, lng: 22.841667 },
    { name: "Kajaani, Oulu", lat: 64.222176, lng: 27.72785 },
    { name: "Naantali", lat: 60.466087, lng: 22.025087 },
    { name: "Oulu, Northern Ostrobothnia", lat: 65.021545, lng: 25.469885 },
    { name: "Espoo", lat: 60.20549, lng: 24.655899 },
    { name: "Turku", lat: 60.45451, lng: 22.264824 },
    { name: "Helsinki", lat: 60.192059, lng: 24.945831 },
  ];

  const onWeatherSet = (data) => {
    setSelectedCityWeather(data);
  };

  const getWeather = () => {
    if (location.lat && location.lng) {
      getCurrentWeatherData(
        { lat: location.lat, lng: location.lng },
        onWeatherSet
      );
    }
  };

  useEffect(() => {
    getWeather();
  }, [location]);

  const handleCitySelect = (city) => {
    setLocation({ lat: city.lat, lng: city.lng });
    setSearchText("");
    setShowDropdown(false);
  };

  const handleCurrentLocationClick = () => {
    setForceUpdateLocation(!forceUpdateLocation);
    setSearchText("");
  };

  const filteredCities = finlandCities.filter((city) =>
    city.name.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <>
      <Coordinates
        onLocationChange={setLocation}
        forceUpdateLocation={forceUpdateLocation}
      />
      <Container>
        <Row className="justify-content-center py-5">
          <Col md={8} lg={6} xl={5}>
            <div className="home-area">
              <div className="searchArea">
                <input
                  type="text"
                  placeholder="Search for a city"
                  className="form-control"
                  value={searchText}
                  onChange={(e) => setSearchText(e.target.value)}
                  onFocus={() => setShowDropdown(true)}
                  onBlur={() => setTimeout(() => setShowDropdown(false), 200)}
                />
                {showDropdown && (
                  <ul className="dropdown-menu show">
                    {filteredCities.map((city, index) => (
                      <li
                        key={index}
                        className="dropdown-item"
                        onClick={() => handleCitySelect(city)}
                      >
                        {city.name}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
              <WeatherCard weatherData={selectedCityWeather} />
              <div className="linkArea">
                <Button onClick={handleCurrentLocationClick}>
                  <FontAwesomeIcon icon={faLocationCrosshairs} /> Current
                  Location
                </Button>
                {selectedCityWeather ? (
                  <Link
                    className="btn btn-success"
                    to={`/forecast?lat=${location.lat}&lng=${location.lng}&city=${selectedCityWeather.name}`}
                  >
                    5-Day Forecast For {selectedCityWeather.name}
                  </Link>
                ) : null}
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default Home;
