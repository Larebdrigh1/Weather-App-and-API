import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { getWeatherForecastData } from "../apis";
import { Col, Container, Row } from "react-bootstrap";
import DailyForecast from "../components/DailyForecast";

const ForeCast = () => {
  const [searchParams] = useSearchParams();
  const [cityName, setCityName] = useState("");
  const [forecast, setForecast] = useState([]);

  const getForeCast = () => {
    const lat = searchParams.get("lat") || 0;
    const lng = searchParams.get("lng") || 0;

    getWeatherForecastData({ lat, lng }, (data) => {
      setForecast(data);
      setCityName(searchParams.get("city"));
    });
  };

  useEffect(() => {
    getForeCast();
  }, [searchParams]);

  return (
    <Container className="py-4">
      <Row>
        <Col xs={12} className="mb-3">
          <h1 className="text-center">Forecast {cityName}</h1>
        </Col>
      </Row>
      <Row style={{ rowGap: 30 }}>
        {forecast.map((item, index) => (
          <Col md={6} xs={12} key={index}>
            <DailyForecast weatherData={item} isForcastScreen />
          </Col>
        ))}
      </Row>
    </Container>
  );
};

export default ForeCast;
