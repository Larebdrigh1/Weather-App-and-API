import { Card, Col, Row } from "react-bootstrap";
import WeatherCard from "./WeatherCard";
import { useSearchParams, useNavigate } from "react-router-dom";

const DailyForecast = ({ weatherData, isForcastScreen = false }) => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const handleDetailsClick = () => {
    navigate("/forecast-details", { state: { weatherData } });
  };

  return (
    <Card
      className="text-body dailyCard"
      style={{ borderRadius: 15, cursor: "pointer" }}
      onClick={handleDetailsClick}
    >
      <Card.Body className="p-4">
        <div className="d-flex">
          <h4 className="flex-grow-1">
            <b>{weatherData.date}</b>
          </h4>
        </div>
        <Row className="justify-content-center" style={{ rowGap: 30 }}>
          {isForcastScreen ? (
            <Col md={12}>
              <WeatherCard
                weatherData={{
                  ...weatherData.entries[0],
                  name: searchParams.get("city"),
                }}
              />
            </Col>
          ) : (
            <>
              {weatherData.entries.map((item, index) => (
                <Col
                  md={3}
                  key={index}
                  className={index > 3 ? "border-top" : "border-top-mob"}
                >
                  <WeatherCard weatherData={item} />
                </Col>
              ))}
            </>
          )}
        </Row>
      </Card.Body>
    </Card>
  );
};

export default DailyForecast;
