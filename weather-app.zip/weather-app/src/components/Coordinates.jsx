import { useEffect } from "react";
import { useGeolocated } from "react-geolocated";
import PropTypes from "prop-types";

const Coordinates = ({ onLocationChange, forceUpdateLocation }) => {
  const { coords, isGeolocationAvailable, isGeolocationEnabled } =
    useGeolocated();

  useEffect(() => {
    if (isGeolocationAvailable && isGeolocationEnabled && coords) {
      onLocationChange({ lat: coords.latitude, lng: coords.longitude });
    } else {
      onLocationChange({ lat: 0, lng: 0 });
    }
  }, [coords, isGeolocationAvailable, isGeolocationEnabled, onLocationChange]);

  useEffect(() => {
    if (isGeolocationAvailable && isGeolocationEnabled && coords) {
      onLocationChange({ lat: coords.latitude, lng: coords.longitude });
    }
  }, [
    forceUpdateLocation,
    coords,
    isGeolocationAvailable,
    isGeolocationEnabled,
    onLocationChange,
  ]);

  return null;
};

Coordinates.propTypes = {
  onLocationChange: PropTypes.func.isRequired,
  forceUpdateLocation: PropTypes.bool,
};

export default Coordinates;
