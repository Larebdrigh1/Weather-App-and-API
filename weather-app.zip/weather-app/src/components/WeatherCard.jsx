import {
  faEye,
  faTemperature0,
  faTint,
  faWind,
  faTemperatureHigh,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Card } from "react-bootstrap";

const WeatherCard = ({ weatherData = undefined }) => {
  return (
    <Card className="text-body" style={{ borderRadius: 15 }}>
      <Card.Body className="p-4">
        <div className="d-flex">
          <h6 className="flex-grow-1">
            {weatherData
              ? weatherData.name
                ? weatherData.name
                : weatherData.time
              : ""}
          </h6>
        </div>

        <div className="d-flex flex-column text-center mt-5 mb-4">
          <h6 className="display-4 mb-0 font-weight-bold">
            {weatherData ? parseInt(weatherData.main.temp) : 0}°C
          </h6>
          <span className="small" style={{ color: "#868B94" }}>
            Feels Like:{" "}
            {weatherData ? parseInt(weatherData.main.feels_like) : 0}°C
          </span>
          <span className="small" style={{ color: "#868B94" }}>
            {weatherData ? weatherData.weather[0].main : "NA"}
          </span>
        </div>

        <div className="d-flex justify-content-center" style={{ gap: 30 }}>
          <div>
            <FontAwesomeIcon
              icon={faTemperature0}
              style={{ color: "#868B94" }}
            />{" "}
            <span className="ms-1">
              {weatherData ? Math.floor(weatherData.main.temp_min) : 0}°C
            </span>
          </div>
          <div>
            <FontAwesomeIcon
              icon={faTemperatureHigh}
              style={{ color: "#868B94" }}
            />{" "}
            <span className="ms-1">
              {weatherData ? Math.ceil(weatherData.main.temp_max) : 0}°C
            </span>
          </div>
        </div>

        <div className="d-flex align-items-center">
          <div className="flex-grow-1">
            <div>
              <FontAwesomeIcon icon={faWind} style={{ color: "#868B94" }} />{" "}
              <span className="ms-1">
                {weatherData ? parseInt(weatherData.wind.speed) : 0} km/h
              </span>
            </div>
            <div>
              <FontAwesomeIcon icon={faTint} style={{ color: "#868B94" }} />{" "}
              <span className="ms-1">
                {weatherData ? parseInt(weatherData.main.humidity) : 0}%
              </span>
            </div>
            <div>
              <FontAwesomeIcon icon={faEye} style={{ color: "#868B94" }} />{" "}
              <span className="ms-1">
                {weatherData ? weatherData.visibility / 1000 : 0}km
              </span>
            </div>
          </div>
          <div>
            {weatherData ? (
              <img
                src={`https://openweathermap.org/img/wn/${weatherData.weather[0].icon}@2x.png`}
                width="100px"
              />
            ) : null}
          </div>
        </div>
      </Card.Body>
    </Card>
  );
};

export default WeatherCard;
