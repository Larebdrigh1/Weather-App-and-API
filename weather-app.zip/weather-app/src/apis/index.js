import Axios from "../helpers/axios";

const APIKey = "dca47e08c68e4623dd1509582d4246e3";
const unit = "metric";

export const getCurrentWeatherData = (
  { lat = 0, lng = 0 },
  callback = () => null
) => {
  Axios.get(`weather?lat=${lat}&lon=${lng}&appid=${APIKey}&units=${unit}`)
    .then((res) => {
      const response = res.data;
      if (response) {
        callback(response);
      }
    })
    .catch((err) => {
      console.error(err);
    });
};

export const getWeatherForecastData = (
  { lat = 0, lng = 0 },
  callback = () => null
) => {
  Axios.get(
    `forecast?lat=${lat}&lon=${lng}&appid=${APIKey}&units=${unit}&cnt=40`
  )
    .then((res) => {
      const response = res.data;
      if (response) {
        callback(formatForecastData(response));
      }
    })
    .catch((err) => {
      console.error(err);
    });
};
const formatForecastData = (forecastData) => {
  const dailyData = [];

  forecastData.list.forEach((entry) => {
    const dateStr = entry.dt_txt.split(" ")[0];
    const dateObj = new Date(dateStr);
    const day = dateObj.getDate();
    const month = dateObj.toLocaleString("default", { month: "long" });
    const formattedDate = `${day} ${month}`;

    const time24 = entry.dt_txt.split(" ")[1].slice(0, 5);
    const [hour, minutes] = time24.split(":");

    const hour12 = hour % 12 || 12;
    const period = hour < 12 ? "AM" : "PM";
    const formattedTime = `${hour12}:${minutes} ${period}`;

    let dayData = dailyData.find((d) => d.date === formattedDate);

    if (!dayData) {
      dayData = {
        date: formattedDate,
        entries: [
          {
            time: formattedTime,
            ...entry,
          },
        ],
      };
      dailyData.push(dayData);
    } else {
      dayData.entries.push({
        time: formattedTime,
        ...entry,
      });
    }
  });

  return dailyData.slice(0, 5);
};
